package cn.hollis.nft.turbo.api.notice.constant;

/**
 * 通知相关的常量
 *
 * @author Hollis
 */
public class NoticeConstant {

    public static final String CAPTCHA_KEY_PREFIX = "nft:turbo:captcha:";
}
