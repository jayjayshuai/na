package cn.hollis.nft.turbo.chain.domain.entity;

/**
 * @author hollis
 */
public interface RequestBody {
}
