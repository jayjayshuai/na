package cn.hollis.nft.turbo.notice.domain.constant;

/**
 * @author Hollis
 */
public enum NoticeType {
    /**
     * 短信
     */
    SMS;
}
