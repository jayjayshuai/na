package cn.hollis.nft.turbo.pay.infrastructure.channel.wechat.entity;

/**
 * @author Hollis
 */
public class WxNotifyResourceEntityPayerEntity {
    private String openid;

    public String openid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }
}
