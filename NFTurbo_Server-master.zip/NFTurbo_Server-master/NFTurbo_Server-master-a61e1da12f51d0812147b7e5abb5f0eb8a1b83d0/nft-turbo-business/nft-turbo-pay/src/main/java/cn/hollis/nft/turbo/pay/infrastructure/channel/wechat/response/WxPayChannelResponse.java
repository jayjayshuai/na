package cn.hollis.nft.turbo.pay.infrastructure.channel.wechat.response;

import cn.hollis.nft.turbo.pay.infrastructure.channel.common.response.PayChannelResponse;
import lombok.Getter;
import lombok.Setter;

/**
 * @author wswyb001
 */
@Setter
@Getter
public class WxPayChannelResponse extends PayChannelResponse {



}
